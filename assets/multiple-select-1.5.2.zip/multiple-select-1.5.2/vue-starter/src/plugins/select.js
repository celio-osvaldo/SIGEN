import 'multiple-select/dist/multiple-select.css'

import './jquery.js'
import Vue from 'vue'
import 'multiple-select/dist/multiple-select.js'
import MultipleSelect from 'multiple-select/src/vue/MultipleSelect.vue'

Vue.component('MultipleSelect', MultipleSelect)
