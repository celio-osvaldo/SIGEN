module.exports = {
  css: {
    loaderOptions: {
      postcss: {
        options: {
          path: './postcss.config.js'
        }
      }
    }
  }
}
